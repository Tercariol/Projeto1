function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  text("Formadores", 138,184);
  fill(color(199,94,235))
}
